package weberichan;

import java.util.Comparator;

public interface Sortable extends Comparator<Student> {

	// extends 는 확장시키겠다, 여기서, 이class에서는 구현하지 않고 더 확장 시킨뒤 구현하겠다는 뜻,
	// 물론 구현할수도 있음
	//implements는 여기서 , 이 class에서 구현하겠다는 뜻
	
}
