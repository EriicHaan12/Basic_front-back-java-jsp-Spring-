//한줄 주석은 자바스크립트와 똑같다.
/* 여러줄 주석은 css와 같다
 * 
 * 저장은 마찬가지로 ctrl +s
 * 코드 힌트도 마찬가지로 ctrl + space
 * 저장이 안되어 있다면 워크시트 앞에 * 이 떠있다
 * 대괄호, 소괄호는 한번만 누르면 짝이 알아서 입력된다...
 * 
 * 보라색은 keyword
 * 
 * 
 * 하나의 자바 프로젝트에는 반드시 프로젝트 명과 같은 이름의 pubilc한 클래스가 있어야 한다.
 */

public class HelloJava { // HelloJava 클래스의 시작 
	public static void main(String[] args) {// main 메서드(프로그램의 실행 시작점)의 시작
		System.out.println("Hello,Java!"); //화면에 입력한 문자열 띄우는 함수
		// printIn은 자동 줄바꿈이 된다.
		
		System.out.print("배고프당ㅎ");
		// print은 줄바꿈이 되지 않는다.
		System.out.println("배고프당..!");
	}
	
	
	}// HelloJava 클래스의 끝


