package weberichan;

public interface Paserable {
	public abstract void parse(String extension);
}
