package weberichan;

public  interface GramLaptop extends Computer, Phone { //interface 끼리도 상속받을 수 있다.



}
