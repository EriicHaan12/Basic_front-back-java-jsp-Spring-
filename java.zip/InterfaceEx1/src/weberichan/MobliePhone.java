package weberichan;

public class MobliePhone implements Phone, Camera,Computer{
//interface 로 만든 클래스는 다중 상속을 구현 할 수 있다
	@Override
	public void computExpressions() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void playingApp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takePicture() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void zoomIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calling() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void receiveCall() {
		// TODO Auto-generated method stub
		
	}

}
