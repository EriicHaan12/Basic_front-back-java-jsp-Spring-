package weberichan;

public interface Phone {
	 void calling(); // public abstract을 생략해도 알아서 붙어있다.
	 void receiveCall();
}
