package weberichan;

public interface Computer {
	void computExpressions();
	
	void playingApp();
}
