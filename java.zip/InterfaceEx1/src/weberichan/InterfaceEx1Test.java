package weberichan;

public class InterfaceEx1Test {

	public static void main(String[] args) {
		

			
		};
		
	

}
