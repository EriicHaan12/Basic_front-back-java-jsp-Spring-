package weberichan;

public interface Remoteable {
void remoteControl(ElectricDevice ed);
}
