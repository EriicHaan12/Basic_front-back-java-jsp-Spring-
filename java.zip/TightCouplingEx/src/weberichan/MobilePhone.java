package weberichan;

public class MobilePhone implements Remoteable{

	@Override
	public void remoteControl(ElectricDevice ed) {
	
		
	}

}
