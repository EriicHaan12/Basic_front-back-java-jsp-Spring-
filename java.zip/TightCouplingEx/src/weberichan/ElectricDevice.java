	package weberichan;
	
	public interface ElectricDevice {
		public void powerOn();
	
	}
