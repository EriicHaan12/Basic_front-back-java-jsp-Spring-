package weberichan;

public class EnglishWord {

}
