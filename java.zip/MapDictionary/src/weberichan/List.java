package weberichan;

import java.util.Iterator;
import java.util.Set;

public class List {
//	private Set<Word> wordSet;
//
//	public Set<Word> getWordSet() {
//		return wordSet;
//	}
//
//	public void setWordSet(Set<Word> wordSet) {
//		this.wordSet = wordSet;
//	}
//
//	public void addWord(Word w) {
//		this.wordSet.add(w);
//	}
//	
//	public void outputEntireWord() {
//		for(Word word : this.wordSet) {
//			System.out.println(word.toString());
//		}
//	}
	
}

