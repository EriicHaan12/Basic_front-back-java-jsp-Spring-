package weberichan;

public class Word {
//	private String wordMean; 
//	
//
//public Word(String wordMean) {
//	this.wordMean= wordMean;
//}
//public String getwordMean() {
//	return wordMean;
//}
//public void setwordMean(String wordMean) {
//	this.wordMean=wordMean;
//}
}
