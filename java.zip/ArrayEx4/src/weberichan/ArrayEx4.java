package weberichan; //이 파일은 weberichan 이라는 패키지에 감싸져 있다는 뜻

import java.util.Arrays;

//이 클래스는 패키지 폴더 주소 안에 위치하고 있다.
public class ArrayEx4 {
	public static void main(String[]args) { 
		System.out.println("메인 메서드의 매개변수, args의 길이 : " + args.length);
		System.out.println(Arrays.toString(args));
		
		
	}
}
