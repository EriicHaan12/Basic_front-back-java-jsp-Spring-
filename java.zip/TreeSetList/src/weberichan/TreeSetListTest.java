package weberichan;

public class TreeSetListTest {


	    public static void main(String[] args) {
	        List link = new List();

	        // 학생 객체 추가
	        link.add(new Student("John", 3, 20, 90));
	        link.add(new Student("Peter", 1, 19, 85));
	        link.add(new Student("Mary", 2, 21, 95));

	        // 학생 객체 출력
	        link.print();
	    }
	


}
