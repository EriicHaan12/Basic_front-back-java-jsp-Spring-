package weberichan;

public class Computer {

}
